<aside class="col-lg-4 col-md-4 sidebar" role="complementary">
    <?php
    if ( ! dynamic_sidebar( __('Pages Sidebar','framework') )) :
    endif;
    ?>
</aside><!-- end of sidebar -->