<?php inspiry_list_gallery_images('grid-post-thumb'); ?>
