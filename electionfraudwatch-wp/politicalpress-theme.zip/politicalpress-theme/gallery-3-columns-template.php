<?php
/*
*   Template Name: Gallery 3 Columns Template
*/

global $gallery_col;
$gallery_col = 3;

global $gallery_image_size;
$gallery_image_size = 'gallery-detail-thumb';

get_template_part('template-parts/gallery');