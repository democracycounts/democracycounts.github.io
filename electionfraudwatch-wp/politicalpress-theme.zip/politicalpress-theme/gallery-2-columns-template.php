<?php
/*
*   Template Name: Gallery 2 Columns Template
*/

global $gallery_col;
$gallery_col = 2;

global $gallery_image_size;
$gallery_image_size = 'gallery-detail-thumb';

get_template_part('template-parts/gallery');