Please consult documentation that comes with this theme for detailed instructions.

If you need any help, You can submit a support ticket at our support site http://support.inspirythemes.com/ .

For General WordPress Issues you can search your issue in Google. As there are thousands of helping articles and forum threads out there to help WordPress users.